# Admission-prediction
Getting Admission in College Prediction
